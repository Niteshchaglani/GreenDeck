package com.greendeck.team;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenDeckApplicationTests {

	@Test
	void contextLoads() {
	}

}
